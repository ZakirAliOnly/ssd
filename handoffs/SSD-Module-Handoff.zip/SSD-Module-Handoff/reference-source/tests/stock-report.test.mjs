import test from "node:test";
import assert from "node:assert/strict";
import { buildStockReport, stockSaleRevenue } from "../lib/stockReport.ts";

const product = {
  id: "p1", code: "1", name: "Vinyl", category: "Print", created_at: "2026-01-01", cost_price: 12,
  batches: [
    { received_date: "2026-01-01", received_qty: 10, remaining_qty: 5,
      allocations: [{ date: "2026-01-31", qty: 2, cost: 8 }, { date: "2026-02-01", qty: 3, cost: 8 }] },
    { received_date: "2026-02-28", received_qty: 5, remaining_qty: 3,
      allocations: [{ date: "2026-03-01", qty: 2, cost: 10 }] },
  ],
  sales: [{ date: "2026-01-31", qty: 2, deducted: 2, revenue: 40 },
    { date: "2026-02-01", qty: 3, deducted: 3, revenue: 54 },
    { date: "2026-03-01", qty: 2, deducted: 2, revenue: 40 }],
};
test("opening, receipts, sales and closing use inclusive invoice and receipt dates", () => {
  const [r] = buildStockReport([product], "2026-02-01", "2026-02-28");
  assert.equal(r.opening, 8); assert.equal(r.received, 5); assert.equal(r.sold, 3);
  assert.equal(r.available, 10); assert.equal(r.revenue, 54); assert.equal(r.cost, 24);
  assert.equal(r.profit, 30); assert.equal(r.warning, null);
});
test("single day includes both receipts and sales on that day", () => {
  const [r] = buildStockReport([product], "2026-02-01", "2026-02-01");
  assert.equal(r.opening, 8); assert.equal(r.received, 0); assert.equal(r.available, 5);
});

test("stock report carries product descriptions and handles missing descriptions", () => {
  const rows = buildStockReport([{ ...product, description: "Outdoor printing vinyl" }, { ...product, id: "p2", description: null }], "2026-02-01", "2026-02-28");
  assert.equal(rows[0].description, "Outdoor printing vinyl");
  assert.equal(rows[1].description, "");
});
test("undated manual stock reductions never create invented historical balances", () => {
  const changed = { ...product, batches: [{ ...product.batches[0], remaining_qty: 4 }, product.batches[1]] };
  const [r] = buildStockReport([changed], "2026-02-01", "2026-02-28");
  assert.equal(r.opening, null); assert.equal(r.available, null); assert.ok(r.warning);
});
test("legacy sales use fallback cost and flag missing balance history", () => {
  const [r] = buildStockReport([{ ...product, sales: [{ date: "2026-02-01", qty: 3, deducted: 0, revenue: 54 }], batches: [] }], "2026-02-01", "2026-02-28");
  assert.equal(r.cost, 36); assert.equal(r.profit, 18); assert.equal(r.available, null);
});
test("missing earlier allocations also flag opening balances", () => {
  const changed = { ...product, batches: product.batches.map(b => ({ ...b, allocations: b.allocations.filter(a => a.date >= "2026-02-01"), received_qty: b.received_qty - 2 })) };
  assert.ok(buildStockReport([changed], "2026-02-01", "2026-02-28")[0].warning);
});
test("future products are excluded and empty categories produce no rows", () => {
  assert.deepEqual(buildStockReport([{ ...product, created_at: "2026-04-01" }], "2026-02-01", "2026-02-28"), []);
  assert.deepEqual(buildStockReport([], "2026-02-01", "2026-02-28"), []);
});
test("invoice discounts are proportional across categories and never produce negative revenue", () => {
  assert.equal(stockSaleRevenue(60, 100, 10), 54);
  assert.equal(stockSaleRevenue(40, 100, 10), 36);
  assert.equal(stockSaleRevenue(60, 100, 200), 0);
  assert.equal(stockSaleRevenue(0, 0, 0), 0);
});

test("returns restore historical stock on their date and reverse revenue and original cost", () => {
  const returned = { ...product,
    batches: [{ ...product.batches[0], remaining_qty: 6, allocations: [product.batches[0].allocations[0], { ...product.batches[0].allocations[1], returns: [{ date: "2026-03-02", qty: 1 }] }] }, product.batches[1]],
    returns: [{ date: "2026-03-02", qty: 1, restored: 1, revenue: 18 }],
  };
  const february = buildStockReport([returned], "2026-02-01", "2026-02-28")[0];
  assert.equal(february.available, 10); assert.equal(february.warning, null);
  const day = buildStockReport([returned], "2026-03-02", "2026-03-02")[0];
  assert.equal(day.opening, 8); assert.equal(day.available, 9);
  assert.equal(day.sold, -1); assert.equal(day.revenue, -18); assert.equal(day.cost, -8);
  assert.equal(day.profit, -10); assert.equal(day.warning, null);
  const later = buildStockReport([returned], "2026-03-03", "2026-03-03")[0];
  assert.equal(later.opening, 9); assert.equal(later.available, 9); assert.equal(later.sold, 0);
});

test("supplier returns reduce stock on the return date without being counted as sales", () => {
  const p = { ...product, batches: [{ received_date: "2026-02-01", received_qty: 10, remaining_qty: 7,
    allocations: [], supplier_returns: [{ date: "2026-02-10", qty: 3 }] }], sales: [] };
  const before = buildStockReport([p], "2026-02-01", "2026-02-09")[0];
  assert.equal(before.available, 10); assert.equal(before.received, 10); assert.equal(before.warning, null);
  const day = buildStockReport([p], "2026-02-10", "2026-02-10")[0];
  assert.equal(day.opening, 10); assert.equal(day.received, -3); assert.equal(day.available, 7);
  assert.equal(day.sold, 0); assert.equal(day.revenue, 0); assert.equal(day.cost, 0); assert.equal(day.warning, null);
  assert.equal(buildStockReport([p], "2026-02-11", "2026-02-11")[0].opening, 7);
});


test("sales detail keeps invoice identity and prices and filters inclusive dates", () => {
  const sales = [
    { date: "2026-01-31", qty: 1, deducted: 1, revenue: 10, invoiceNumber: "OUTSIDE" },
    { date: "2026-02-28", qty: 0.5, deducted: 0.5, revenue: 20, lineId: "l2", invoiceId: "i2", invoiceNumber: "INV-2", customer: "Customer B", unitPrice: 50, amount: 22.5 },
    { date: "2026-02-01", qty: 2, deducted: 2, revenue: 54, lineId: "l1", invoiceId: "i1", invoiceNumber: "INV-1", customer: "Customer A", unitPrice: 30, amount: 60 },
    { date: "2026-03-01", qty: 1, deducted: 1, revenue: 10, invoiceNumber: "AFTER" },
  ];
  const [row] = buildStockReport([{ ...product, sales }], "2026-02-01", "2026-02-28");
  assert.deepEqual(row.sales, [sales[2], sales[1]]);
  assert.equal(row.sales[1].qty, 0.5);
  assert.equal(row.sales[1].unitPrice, 50);
  assert.equal(row.sales[1].amount, 22.5);
  assert.equal(row.revenue, 74);
  assert.equal(row.sold, 2.5);
});
