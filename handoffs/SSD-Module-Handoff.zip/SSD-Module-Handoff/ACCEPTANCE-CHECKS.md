# Acceptance checks for the destination implementation

Run these using synthetic data in an isolated new database. They are specifications with expected results, not a claim that an implementation already exists in the new project. Record pass/fail/skipped/unimplemented separately. Also adapt the relevant reference-source/tests files; the original tests are examples, not sufficient coverage of every module.

## Login and authorization

- Empty credentials => validation error; wrong email/password => rejection without a session; valid credentials => session set and appropriate landing page.
- A disabled user cannot log in, obtain an active session profile or make data mutations. Disabling an already logged-in user takes effect on privileged server checks.
- Session cookie is HttpOnly, SameSite policy is appropriate and production sessions are Secure. Passwords are hashed, never returned; missing required signing configuration fails closed.
- Unauthenticated API calls are rejected (or explicitly documented redirect behavior), and forbidden module access is rejected server-side even when the UI route is bypassed.
- Create a sub-user with only workers: Workers loads; unrelated Products, Supplier and User Management actions are denied; worker workflow lookup/cash commands work only through their authorized boundary.
- Admin edits module grants: subsequent requests respect new grants. A sub-user cannot edit its own role/modules or impersonate another audit actor.
- Source-parity user cap: five sub-users can exist; a sixth is rejected, including concurrent creates. Duplicate normalized email is rejected.
- Admin can reset another sub-user password without the target's current password. Admin self-change requires current password. The recorded destination password policy is applied consistently.
- Delete a sub-user: user disappears and one durable deletion audit remains. Reject deleting a super admin through the sub-user endpoint.

## Payment methods and Cash Book

Fixture: Cash opening = 1,000; Bank opening = 500.

- Cash receipt 200 and Cash expense 150 => Cash = 1,050. Bank remains 500.
- Add a ledger-only Opening balance entry for 900 and an Adjustment entry for 300 => method cash balances remain Cash 1,050 and Bank 500; party ledger reflects the appropriate signed bookkeeping effect.
- Transfer 250 Cash -> Bank => Cash = 800, Bank = 750; total = 1,550 before and after the transfer. Both rows share one transfer reference.
- Reject same-method transfer, nonpositive amount and transfer larger than available source funds. Fail the second insert deliberately: neither row remains.
- Delete/reverse a transfer => both sides are removed/reversed together, restoring balances without deleting unrelated entries.
- Archive Bank => it disappears from new pickers while history is retained. Restore => selectable again. Reject case-insensitive duplicate method names.
- Rename a method with history => funds stay attributed to that method under the documented id/migration design. No unexplained second wallet appears.
- A cash-out failing funds validation writes no cashbook row or dependent business record. Two simultaneous outflows cannot jointly spend more than available funds if the destination enforces source workflow funds limits.
- Cashbook edit excludes its own existing amount when computing available funds, avoiding double subtraction. Deletion updates dependent balances/settlement as designed.
- Same display name for customer and supplier does not cause a supplier payment to reduce the customer balance.
- An invoice amount_received of 200 with a linked cashbook receipt of 200 contributes a 200 credit, never 400. If customer billing is excluded, exercise this at the adapter/unit-test boundary.

## Workers and payroll

Fixture: monthly salary 30,000; advances 5,000; 4 overtime hours at 250/hour; absent days 2.

- Per-day rate = 30,000 / 30 = 1,000, even when standard_working_days = 26.
- Overtime = 1,000; absence deduction = 2,000; adjusted gross = 29,000; net salary cash-out = 24,000.
- Total worker cash movement = prior advance 5,000 + salary 24,000 = 29,000. Do not pay 29,000 again at settlement.
- Pay the same worker/month again => rejected with no extra payroll or cash row. Simultaneous requests and retries also cannot duplicate it.
- All consumed extra-hour rows link to that payroll; cannot delete a linked extra-hours entry or add new extra hours after settlement for that month.
- Advance totals greater than monthly salary => rejected. Insufficient method funds => rejected with no partial record.
- Advances fully covering adjusted gross => netPaid 0; payroll recorded, no new cash-out. The source clamps negative net to zero; do not invent an automatic negative payment.
- Delete an unconsumed advance => linked cash effect is removed/reversed once under the chosen policy. Archiving/deleting worker with financial history follows documented retention and does not leave unexplained cash changes.
- Failure between business write and cash write rolls back the whole command.

## Expenses

- Paid expense of 300 => Expense row plus exactly one linked Cashbook out of 300. Funds fall by 300.
- Same amount with method Unpaid => Expense row, no cash movement.
- Pending invoice expense with amount 0 => no cash movement; later paid completion creates one cash-out.
- Change paid 300 to paid 350 => net cash change is an extra 50, not a second 350 deduction.
- Change paid to Unpaid => remove/reverse the prior cash effect once. Change Unpaid to paid => create exactly one linked cash-out.
- Delete paid expense => linked cash movement is handled once according to the documented delete/reversal policy; no orphan rows.
- Add multiple project expense rows: funded paid rows affect method balance, Unpaid rows do not; completion/reopen state changes do not duplicate spending.
- Concurrent expense creations get distinct identifiers; sequence works beyond 300 historical records.

## Suppliers and purchases

Fixture: supplier opening payable 1,000; purchase 2,000; payment 500.

- Line qty 2 × rate 1,000 => line total 2,000; amountPaid 500 => balanceDue 1,500, status partial.
- Supplier payable = 1,000 + 2,000 − 500 = 2,500, not 2,000 or 3,000. Header amount_paid and its cashbook row represent one payment.
- Create paid purchase => invoice/items, received stock and cash effect are coherent. Inject failure during stock/payment linkage => no partially applied command.
- Fully unpaid purchase => no cash-out but stock and payable increase. Fully paid purchase => paid status with zero purchase balance.
- Reject additional payments beyond net outstanding (including any return credit). Preserve the declared rounding policy.
- Referenced supplier payment remains with its supplier when another customer shares the same name. Ambiguous legacy name-only rows raise a warning.
- Editing a purchase cannot reduce received quantities below stock already consumed. Deleting a purchase with payments/returns is blocked until allowed resolution; history is not silently erased.
- If supplier returns exist through an adapter, credit reduces payable but does not move cash. A separate supplier cash refund is real cash in and must be counted once.

## Products, packaging and stock

- Category '  Medical   Supplies  ' normalizes to 'Medical Supplies'; its normalized duplicate is rejected. Missing/invalid category on product creation is rejected.
- Reject negative/nonfinite prices, invalid quantities and more than two decimal places in stock. Cost precision survives calculation/storage without premature two-decimal truncation.
- Packaging: 10 pieces/packet × 5 packets/box => one box is 50 base units. Receive 2 boxes => stock 100. Consume 1 packet + 3 pieces => stock 87, when a sales/consumption adapter is implemented.
- No configured packet price with base price 12 => packet default price 120; configured packet price 110 => use 110. Later price edits do not rewrite historical transactions.
- With 23 base pieces and 10 per packet, stock breakdown is 2 packets plus 3 pieces, total 23. Kit/vial wording maps onto the same physical base-unit logic.
- A historical transaction snapshots unit factor 10; change product packaging factor to 12 => old movement remains 10, not 12.
- Two concurrent movements cannot oversell stock. A stock edit with stale expected_quantity is rejected. A packaging conversion cannot race a transaction into mixed bases.
- Receive batches with distinct expiry/cost; FIFO allocations, remaining batch units and product quantity reconcile. Expiry updates go through the relevant receipt batch, not a direct product-field overwrite.
- Delete unused product with only unused opening batch => supported with audit. Delete product with purchase/sale history => blocked. Use adapter-level tests if sales is outside destination scope.

## Activity and footer

- Real actor identity is server-derived even when a forged actor is in the request body. Verify a completed financial action and a deletion show the expected actor/date/entity/amount.
- Failed deletion => neither business deletion nor deletion audit committed. Successful deletion => durable snapshot, without a duplicate client-side deletion event.
- Timeline filters include only matching period/type/search events; source documents outside the ten-module scope are not fabricated.
- Normal users cannot modify/delete audit history through public endpoints. Critical create/update events are durable under the chosen improved audit policy.
- Credit 'Software developed by AddsMint.com' is visible on login, main shell and implemented printed/PDF documents, with no overlap. New business branding is configurable and original company contacts are not accidentally shipped.

## Final evidence

Run destination build/type checks, meaningful formula tests, database integration tests for linked operations and permissions, and a representative browser flow per module. Document migration commands and environment variable names without values. List any omitted adapter/workflow, legacy data caveat or deliberate departure from SSD. A screenshot or green build alone does not prove financial parity.
