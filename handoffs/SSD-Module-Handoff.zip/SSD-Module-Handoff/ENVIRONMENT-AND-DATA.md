# Environment and database notes

The reference app uses Node.js (Next.js 16-compatible; current inspection ran Node 24), npm with a package lock, Next.js 16.2.1, React 19.2.4, TypeScript, PostgreSQL and Prisma 6.19.3 as locked in the original manifest. Original dependency files are included for version context, not as a recommended manifest for a different stack or a guarantee the source subset builds by itself.

Required variable names for an equivalent original-stack implementation:

- DATABASE_URL: the NEW application's PostgreSQL database; never the old production database.
- JWT_SECRET: a newly generated strong signing secret if retaining JWT auth; do not copy the hardcoded source fallback.
- ADMIN_EMAIL and ADMIN_PASSWORD: only if adapting scripts/create-admin.mjs to provision the initial admin. Supply securely, not in committed fixtures. The source helper also documents ADMIN_LOCATION, but that is not part of its actual user-create data in the inspected code.

The ten modules do not require a GitHub token, Supabase service-role key, original WhatsApp session or WhatsApp encryption key. Supporting source has WhatsApp hooks because of existing coupling; disable/adapt them rather than making messaging credentials a prerequisite.

For a fresh destination, design migrations for the selected models and required references. Prisma schema includes unrelated application models because it is the full structural reference; extract a coherent migration set instead of indiscriminately pushing it over a pre-existing schema. No database contents are supplied. Use synthetic test fixtures only.

Primary selected model families:

- User, PaymentMethod, Cashbook, Expense, ActivityLog.
- Worker, WorkerAdvance, WorkerExtraHours, WorkerPayment.
- Supplier, PurchaseOrder, PurchaseOrderItem.
- ProductCategory, Product, StockBatch, StockAllocation.
- Minimal Account/HeadAccount references or adapters for manual cashbook entries.
- Optional invoice/return reference adapters and their allocation/credit semantics if those integrations are supported.

The full field-by-field definitions are in reference-source/prisma/schema.prisma and the generated DATABASE-MODELS.md. The latter separates selected models from contextual models. Defaults and relationships describe the original; destination migrations must also implement new transactional constraints identified in PORTING-NOTES.md.
