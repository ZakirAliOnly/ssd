# Copy this prompt to the coding agent working on the NEW project

Implement the following modules in this destination project using the attached SSD-Module-Handoff package as the business-logic reference:

- Workers and payroll
- Expenses
- Payment Methods and transfers
- Activity Log
- User Management with module access
- Footer credit
- Login and session management
- Cash Book
- Suppliers and purchase invoices/POs
- Products, categories and stock

First inspect this destination repository and follow its instructions, architecture and existing UI conventions. Read START-HERE.md, IMPLEMENTATION-BRIEF.md, PORTING-NOTES.md, ACCEPTANCE-CHECKS.md and SOURCE-MANIFEST.json before implementing. Use the attached reference-source directory to resolve formulas, permissions, validation, field relationships and workflow details. It is reference material, not a complete app to paste into the destination.

Preserve the business outcomes: salary uses a fixed 30-day absence divisor; advances are deducted once; paid expenses create linked cash-out entries while Unpaid expenses do not; method balances exclude bookkeeping-only entries; transfers conserve total money; supplier balances do not double count payments; inventory changes preserve batch/FIFO history and unit-factor snapshots; users can access only their assigned modules. Keep money at the documented decimal precision and date-only fields as date-only values.

Implement all ten modules end to end with database migrations, server-side authorization and validation, usable pages/forms, search and filters where specified, error/loading/empty states and the linked financial workflows. Reuse existing destination functionality instead of creating duplicates. Treat employer worker roles and application user roles as different concepts.

Do not copy original company branding/contact details, cookie name, production host paths, credentials, deployment configuration or a fallback JWT signing secret. Use the destination's identity and authentication architecture. Display the footer credit "Software developed by AddsMint.com" in the app/login and print/PDF surfaces requested in the brief. The original invoice size is contextual; this request does not require adding a complete invoice module.

Implement financial commands as atomic server transactions with concurrency-safe validation, uniqueness and retry/idempotency protection. The old app contains client-orchestrated multi-request flows; preserve their intended outcomes without carrying over partial-write, race or authorization weaknesses. PORTING-NOTES.md identifies concrete cases. Keep destructive legacy behavior explicit and documented; use archive/restrict when deleting financial history would be unsafe, and report any intentional departure from source behavior.

Do not implement WhatsApp, quotations, delivery challans or the full customer billing system simply because supporting files mention them. Define adapter interfaces for out-of-scope integrations; use disabled/no-op adapters for optional messaging. Include the minimal account references Cash Book needs. Use an isolated new database and synthetic fixtures. Do not contact the old production system or send external messages.

Proceed with reasonable defaults based on the destination project. Ask only if a missing decision genuinely blocks work; otherwise state your assumptions. If the original rule conflicts with destination requirements, explain the conflict before changing business behavior. Track source parity versus deliberate improvements in a short decision log.

Run meaningful unit and database integration tests for the acceptance checks, test permissions directly through server endpoints, build/type-check using the destination's tooling and exercise representative browser workflows. Document anything failed, skipped or not implemented. Finish with files changed, migration/setup commands, verified behavior and remaining limitations. Do not claim completion based only on static pages or a successful build.
