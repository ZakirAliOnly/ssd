# Business logic and module requirements

This brief describes the inspected source, with porting improvements explicitly separated in PORTING-NOTES.md. For exact code, open the paths listed in SOURCE-MANIFEST.json relative to reference-source/. The original is a single-business application with shared business records, not a tenant-isolated SaaS design.

## Shared architecture and integration map

| Module | Primary entities | Required dependencies |
| --- | --- | --- |
| Login | User, signed session | Password hashing, cookie/session middleware |
| User Management | User role and modules | Login, server permissions, Activity Log |
| Payment Methods | PaymentMethod, paired Cashbook transfers | Cash Book, permissions |
| Cash Book | Cashbook, minimal Account references | Methods, supplier/customer identity, audit |
| Workers | Worker, WorkerAdvance, WorkerExtraHours, WorkerPayment | Methods, Cash Book, audit |
| Expenses | Expense, optional Invoice reference | Methods, Cash Book, audit |
| Suppliers | Supplier, PurchaseOrder, PurchaseOrderItem | Products/stock, Methods, Cash Book, audit |
| Products | ProductCategory, Product, StockBatch, StockAllocation | Supplier purchases and optional sales adapters |
| Activity Log | ActivityLog plus supported business events | Logged-in actor, immutable deletion snapshots |
| Footer Credit | Presentation only | App shell, login, print/PDF templates |

The original client `lib/db.ts` has a Supabase-like `db.from(...).select/insert/update/delete` API, but it sends requests to the local `/api/db` route, which uses Prisma/PostgreSQL. Do not infer that a Supabase account or service-role credential is required. The generic route also offers specialized save_purchase and save_invoice commands for transactional inventory operations. It authenticates a session, reads the current user and authorizes table operations. A new implementation can use typed domain endpoints instead.

Core field definitions, database decimal types, relations, indexes and delete actions are in `prisma/schema.prisma`. That file includes out-of-scope models for context; do not apply the full schema to an existing destination database without an explicit migration design.

## Workers

Reference: app/(dashboard)/workers/page.tsx; Worker* schema models.

Maintain name, phone, job role, monthly_wage, status, hourly_overtime_rate and standard_working_days. Show active workers, selected payroll month, salary total, advances and paid amounts. Provide create/edit/delete with confirmation and month-based history. The job role is descriptive, not an application permission role.

Record advances against worker, month (YYYY-MM), date, amount, notes and selected active method. Total advances for the month cannot exceed monthly salary. Validate method funds before cash-out. An advance creates a linked Cashbook `out` row and a WorkerAdvance row; deleting an advance removes the linked cash-out in the existing workflow.

Record extra hours before the month is paid: hours > 0, rate > 0, amount = round(hours × rate, 2). Extra-hour entries carry a month and optional payment_id; linked entries cannot be deleted from the extra-hours screen. Once wages are paid, further extra hours are blocked for that month.

Salary settlement:

- totalWage = monthly_wage.
- advanceTotal = sum of worker advances for the payroll month.
- overtimeAmount = sum of unpaid extra-hour amounts, rounded to 2 decimals.
- perDayRate = monthly_wage / 30. The current formula deliberately uses 30, not the stored standard_working_days (default 26).
- absentDays = nonnegative entered number; absenceDeduction = round(absentDays × perDayRate, 2).
- adjustedGross = totalWage + overtimeAmount − absenceDeduction.
- netPaid = max(0, adjustedGross − advanceTotal).

Block duplicate salary settlement for the same worker/month. Positive netPaid requires an active funded method and creates one cash-out. A zero settlement still creates the payroll record without a cash movement. Persist salary, advances, overtime hours/amount, absent days/deduction, notes, paid_date, actor and linked cashbook row as a historical snapshot; link the consumed overtime rows to the payment. Optional WhatsApp salary text is not needed in the new project.

## Expenses

Reference: app/(dashboard)/expense/page.tsx; lib/expenses.ts; Expense model.

Maintain expense_number, category, description, amount, date, method, completed, optional invoice reference and cashbook_entry_id. The screen has ordinary expenses and invoice/project expense groups, with today/month totals, detail rows, completion/reopen actions and print output.

Paid positive expenses create a linked Cashbook `out` entry. `Unpaid` is a reserved method meaning credit/pending payment; it creates no cashbook movement. A zero-amount placeholder attached to an invoice is pending and creates no cash movement. Later completing it with a positive paid amount creates the cash-out. Updating a paid expense adjusts its linked row; switching it to Unpaid removes/reverses the linked cash-out according to the original flow. Switching back creates a linked paid movement. Never deduct twice. Deleting an expense in the UI also removes its linked cash entry.

The helper numbers expenses EXP-001, EXP-002, etc.; its current latest-300 max+1 approach is a legacy implementation detail, not safe concurrent numbering. Use a server-side sequence/unique allocation for the port. Category and positive row amount validation, active method checks and sufficient method funds apply to paid rows. Preserve optional invoice linkage through an adapter if the destination has no invoices.

## Payment Methods

Reference: app/(dashboard)/payment-methods/page.tsx; lib/paymentMethods.ts; components/TransferModal.tsx.

Admin-configurable names (Cash, bank, wallet, etc.), opening_balance, archived and sort_order. Trim names; reject case-insensitive collisions and negative opening balances in the workflow. Active methods appear in pickers sorted by sort_order then name. Archive removes a method from new payment pickers while retaining history; restoration makes it selectable again.

Normalization: missing/blank method defaults to Cash; legacy exact alias `Mobile Wallet` maps to EasyPaisa. Names are arbitrary strings in source, not a fixed enum.

For each method: balance = its opening_balance + sum(real in) − sum(real out). Exclude opening-balance descriptions, balance-adjustment descriptions and method `Adjustment` (case-insensitive after trimming). Active methods seed their opening balances even without transactions. The helper also tallies archived/legacy names found in historical rows rather than discarding those transactions.

Transfers require different source/destination methods, amount > 0, sufficient source balance, date and optional note. Create equal `out` and `in` entries with a shared `transfer:` reference, then group them as one transfer in history. Edit/delete must affect the pair consistently; total money across methods is unchanged by a transfer.

Legacy caveats: renaming currently changes the method name without migrating historical string references, and permanent deletion can remove associated cashbook history. Preserve archive/restore parity; see PORTING-NOTES.md before implementing rename or hard delete.

## Activity Log

Reference: app/(dashboard)/activity-log/page.tsx; lib/activityLog.ts; server auditDeletion in app/api/db/route.ts.

The page is an activity timeline, not just a dump of ActivityLog rows. It combines supported business events (invoices/returns, receipts, payments, payroll, purchases, quotes) with deletion audit records. Filter by period, event type and search as provided in the source; show title, description/context, actor, timestamp and amount when applicable. In a ten-module port, display only implemented events plus any deliberate adapters.

ActivityLog fields: action, entity_type, entity_id, title, subtitle, nullable amount, metadata, actor id/email/name and created_at. Source metadata is a JSON-encoded string. Server stamps the actor on inserted activity rows; clients must not impersonate another user. Create/update logging through lib/activityLog.ts is best-effort in the source; deletion logging is server-side in the same transaction as deletion. The client helper intentionally does not duplicate deletion events. Deletion snapshots must survive removal of the original business row/user. Deleting ActivityLog via generic API is blocked. A new append-only audit design may strengthen update protection; see notes.

## User Management

Reference: app/(dashboard)/users/page.tsx; app/api/users/route.ts; lib/moduleAccess.ts.

Two roles: super_admin and sub_user. Super admin manages users. Original cap: 5 sub-users total (the server counts role=sub_user, not only active users). Create requires full name, normalized unique email and password of at least 6 characters in that endpoint. Hash passwords with bcrypt cost 12. Password hashes must never be returned to the client.

Admin PATCH can change a sub-user's name, password or module grants without knowing that user's current password. Delete endpoint accepts only a sub-user, and user deletion plus audit event are transactional. User schema also contains is_active; session/data access check current active state. Do not assume the supplied management endpoint exposes an activation toggle just because the schema has this field.

Validate the module list: nonempty array, known module ids only, deduplicate values. The original defaults `accounts` and `quick-invoice` refer to modules outside this requested port; do not assign those as unusable defaults in the new application. Define an explicit destination default and record it.

Original page module ids relevant here: workers, expense, payment-methods, activity-log, cashbook, supplier, products. User Management is super-admin-only and is not a normal grantable module. Super admin bypasses module restrictions. A sub-user cannot gain access by typing a URL or calling the API directly. Read dependencies allow pages to read required lookup/financial tables without granting unrelated screen access. See the complete TABLE_MODULES and READ_DEPENDENCIES matrices in lib/moduleAccess.ts. In particular, several modules can write Cashbook as part of their workflows; payment methods are readable by any user with module grants. Sub-users cannot delete suppliers or purchase invoices/items under the original table policy.

## Footer Credit

Reference: components/PrintFooter.tsx, components/Sidebar.tsx, app/page.tsx and components/InvoiceDocument.tsx.

Display `Software developed by AddsMint.com` as the shared credit. The app navigation/login also include AddsMint.com credit/link; preserve this developer identity while making the destination business name, logo and contact information configurable. Use a shared component/configuration so print/PDF and screen credits do not drift. Keep it visible and legible without covering tables or totals. For paginated documents retain page numbering separately. The original 8.5 × 6.5 inch invoice template is reference context, not a requirement to shrink all new app reports to that paper size.

## Login

Reference: app/page.tsx; app/api/auth/{login,session,logout}/route.ts; lib/auth.ts; middleware.ts; dashboard layout and user-profile helpers.

Provide email/password login, required fields, error state, submit loading state and authenticated routing. Server normalizes submitted email, finds user, verifies bcrypt hash and rejects disabled users. Source responses: missing credentials 400, invalid credentials 401, disabled user 403, success 200 with ok:true and a session cookie.

Original session is HS256 JWT with 7-day lifetime, HttpOnly cookie, SameSite=Lax and Secure in production. Use a destination-specific cookie/key or the destination's existing auth framework; never reuse a default secret. Login response does not expose password hashes. Session lookup reloads current user/role/modules/is_active from the database, preventing stale token claims from being the sole authority for those checks. Logout expires the cookie.

Authenticated super admins land on dashboard in the source; sub-users land on their first allowed module or access-denied page. Preserve equivalent behavior with destination routes. The original middleware redirects unauthenticated non-login paths (including some API paths) to login. For a new API, explicit 401/403 JSON is usually clearer; document this transport difference. The source admin password-change endpoint requires the current password for self-change, but not for resetting another user's password; it uses an 8-character new-password minimum. Do not silently treat that as the same 6-character policy as sub-user creation; select a consistent destination policy explicitly.

## Cash Book

Reference: app/(dashboard)/cashbook/page.tsx; lib/cashbookEntries.ts; lib/paymentMethods.ts; lib/partyBalance.ts; lib/partyInvoiceSettlement.ts; lib/ledger.ts.

Records carry type (`in` or `out`), positive amount, description, date, method, reference, optional account name, actor and creation timestamp. Provide add/edit/delete, account/method/date/type/search filtering, real-cash totals and historical views. New manual rows in source require selecting an existing account; legacy blank-account rows can be edited without forcing a new account. New modules therefore need a minimal account lookup/catalog or an adapter to existing customers/heads.

Cash balance and per-method totals count actual cash, not ledger-only bookkeeping. Recognize opening rows by /^opening balance/i; recognize adjustments by method Adjustment or /^balance adjustment/i. These entries can affect party ledgers without affecting cash on hand. Paired method transfers move money between methods and net to zero globally.

Customer ledgers: an invoice is a debit (customer owes us); a real cash receipt is credit, and a real cash refund is debit. Ledger-only `in` means debit and ledger-only `out` means credit, the reverse of receipt semantics. Do not duplicate invoice amount_received if an actual cashbook payment with reference=invoice id already exists. Positive signed party balance means they owe the business. The ledger is authoritative; accounts.balance is a cache. Cashbook edits/deletes trigger server settlement/recomputation where appropriate.

Supplier-looking rows must not update a same-named customer. Reference ids and context matter, not just account_name. Return credit rows use noncash Adjustment; they are protected from manual editing/deletion, and actual cash refunds are separate movements. These adapters can remain out of scope if the new app lacks sales/returns, but any imported rows must retain correct meaning.

## Supplier and purchase invoices / POs

Reference: app/(dashboard)/supplier/page.tsx; lib/purchaseInventory.ts; lib/supplierStatement.ts; lib/supplierReturns.ts; components/PurchaseOrderPdfDocument.tsx.

Supplier master fields: name, phone, address, notes, opening_balance and creation time. Provide create/edit, search, payable overview, payment history/statement and protected deletion. Original permission rules reserve supplier deletion for super admin.

A purchase invoice contains unique po_number, supplier identity and contact snapshot, date, items, subtotal/total, amount_paid, balance_due, payment_status, payment method, notes and linked payment. Each line references an optional product plus description, quantity, rate, expiry and selected unit/factor. Line amount = round(qty × rate, 2). Paid amount is bounded to [0, grandTotal]; balanceDue = round(grandTotal − amountPaid, 2). Status is unpaid when no paid amount and positive balance, partial when paid and owing, otherwise paid. Payment updates after returns use the net amount after credit.

Purchases and stock receipts are saved together server-side, locking inventory units. Receipt creates/updates batches and quantities rather than allowing disconnected header/item writes. Adding payments creates Cashbook out rows with supplier/purchase references and checks available method funds in the workflow. A purchase with returns cannot be edited/deleted; a purchase with payments cannot be deleted until its payments are resolved. Do not reduce a historical receipt below stock already consumed. Preserve FIFO cost/expiry lineage on edits/deletes.

Supplier payable consists of opening payable + purchase liabilities − cash paid − noncash supplier return credits, with cash refunds increasing payable in the statement direction. Never add amount_paid as a second payment alongside its linked cashbook row. Current opening_balance can be a remaining opening payable; lib/supplierStatement.ts reconstructs original opening as remainingOpening + max(0, actualCashOut − purchasePaidTotal), then builds dated rows. Match rows using supplier ids/purchase ids/linked cash ids first. Legacy name-only matching is allowed only for an unambiguous supplier name not shared with a customer; otherwise show an attribution warning.

For existing returns, receipt history and credit must remain intact; cash refunds are separate. The full Returns page is not part of this requested port, so define its integration boundary rather than inventing return records.

## Product, categories and inventory

Reference: app/(dashboard)/products/page.tsx; lib/productValidation.ts; lib/productUnits.ts; lib/inventory.ts; lib/inventoryUnits.ts; related product components.

Maintain unique numeric product code, name, description, category, cost/sale price, stock quantity and packaging data. Provide listing/search/category filters, create/edit, category maintenance, stock breakdown, expiry/batch details, and protected deletion. Categories normalize whitespace, require 1–100 character names, and have case-insensitive name_key uniqueness. Product creation requires a valid category UUID. New products use standalone pricing. Numeric stock is nonnegative with up to two decimals and a source validation ceiling of 2,147,483,647. Prices must be finite/nonnegative; preserve schema precision (cost_price Decimal(20,8), sale/pack prices Decimal(12,2), quantity Decimal(14,2)).

Stock is stored in base units. Packaging has enabled flag, base_unit label, pieces_per_packet, packets_per_box, optional packet/box prices and conversion timestamp. Sizes are positive integers; total base units per box cannot exceed 1,000,000. Packets/kits and pieces/vials are display/input units, not separate inventory pools. Example: 10 pieces/packet and 5 packets/box means one box = 50 base units. A transaction snapshots unit_factor; later packaging edits must not change historical quantities. Use explicit configured packet/box prices; zero/unset values fall back to rounded base sale price × unit factor.

Expiry belongs to purchase batches; the API rejects direct product expiry edits after creation. Allow non-expiry stock. FIFO batches, stock allocations, return allocations and receipt lineage must reconcile to product.quantity. Standalone opening stock needs a batch; manual adjustments use expected_quantity for optimistic conflict detection and must preserve allocation history. Legacy packaging conversion is a deliberate one-time operation, not a free edit of conversion timestamp. Serialize conversion with inventory writes so quantities cannot mix old and new bases.

Products with purchase/sale history cannot simply be deleted. An unused opening batch can be removed with an otherwise unused product; audit deletion in the same transaction. For stock tracked through purchases and optional sales, prevent overselling, preserve physical quantities on edits and retain enough history to reconcile stock and costs.

## Data representation and delivery requirements

Use decimal-aware server arithmetic and round at the documented operation boundary, not by rendering formatted strings and parsing them back. Persist date-only business fields as YYYY-MM-DD; audit timestamps retain timezone-aware instants. Use UUID identities for entities and preserve references across modules. Provide indexes and uniqueness for lookups and transaction identities. Keep source identity strings in import compatibility adapters where necessary, but prefer stable foreign keys in a fresh destination.

Include accessible labels, keyboard-operable forms/dialogs, confirmation for destructive actions, clear loading/error/empty states, and server validation independent of UI. Do not make a page visible before its data authorization has been checked. Use reusable shared components and configurable business branding. A modern destination UI can differ visually while preserving the listed workflows and domain semantics.
