# Porting notes: parity and deliberate improvements

The source is the reference for business meaning, not a guarantee that every flow is transactional or every guard is server-enforced. These are specific observations from the inspected revision. This is not a comprehensive security audit. Do not silently change financial formulas while correcting implementation weaknesses.

| Source observation | Preserve | Improve explicitly in the new project |
| --- | --- | --- |
| Payroll, advances, expense and some payment workflows use multiple client requests | One intended operation creates the correct linked records | Move the whole command into a transaction; inject a failure in tests to prove no orphan cash movement |
| Salary duplicate/advance/funds checks are largely orchestrated in the screen | One salary per worker/month, capped advances, funded outflows | Enforce in server transactions with locks/constraints; retry must not pay twice |
| Expense numbering uses latest 300 rows and max+1 on the client | EXP-style sequential identifiers | Allocate on the server with unique constraint and collision handling |
| Method name is used as a cashbook string key | Historical balance attribution | Prefer method_id; preserve display-name history and aliases |
| Editing a payment method name updates only its master row | User can rename a method | Migrate references atomically or use stable ids so old funds do not become stranded |
| Permanent method deletion explicitly cascades cashbook deletion in the screen | Archive/restore and clear user confirmation | Default to archive/restrict when history exists; do not carry destructive cascading forward without explicit owner acceptance |
| Deleting a worker cascades payroll/advance/extra-hour models, while cashbook links are plain ids in those models | Worker history is understandable and finances reconcile | Prefer archive; define linked cashbook retention/reversal policy and test against orphan or duplicate cash rows |
| Create/update activity logs are best-effort and the activity screen also derives events from business tables | Actor, time, entity and amount are visible | Audit critical commands transactionally; avoid duplicates when combining stored/derived events |
| Generic API explicitly blocks ActivityLog delete but does not establish a comprehensive immutable-audit policy | Deletion snapshots survive record removal | Make audit append-only on all write paths, including updates and direct domain APIs |
| Source JWT implementation has a hardcoded fallback if JWT_SECRET is absent | A valid signed, expiring session | Require a real destination secret or managed auth; fail closed rather than copy the fallback |
| Some legacy auth/admin code uses token claims rather than fresh role checks | Super-admin-only management and current-user access | Revalidate actor is_active/role server-side for each privileged operation; test revoked access |
| Password minimum differs: 6 for sub-user creation, 8 for separate password-change route | Password validation and bcrypt cost 12 | Pick one destination policy and document that intentional difference |
| Source cap is five sub-users and is checked before creation | Source cap unless owner changes it | Prevent concurrent creates exceeding cap; make cap configurable only if recorded as a requirement change |
| Original default module grants are accounts and quick-invoice | A user must have usable allowed modules | Choose valid defaults for these ten destination modules instead of exposing absent routes |
| Original business records are shared by one business | Same business access semantics | Do not claim tenant isolation. If the destination is multi-company, add tenant ownership/constraints and tests as separate architecture work |
| Middleware may redirect protected API calls to login | Authentication gates all protected actions | Prefer consistent JSON 401/403 for destination APIs; verify response body/type, not just final HTTP 200 after redirect |
| Customer/supplier relationships include legacy names and string references | Correct ownership and no double counting | Use ids for new records; warn on ambiguous imported names instead of guessing |
| Optional WhatsApp imports are transitively present | Core commands work without messaging | Use an optional disabled adapter; do not request WhatsApp credentials for the ten-module implementation |

The reference subset contains schema relations to invoices, returns, reports, quotes and WhatsApp. Keep only required models or define adapters in the destination. Removing dependencies must not weaken inventory/ledger invariants. Explain deliberate exclusions in the delivery notes.

Reference-source package scripts assume a full original application, including scripts that may not be present in this subset. Do not blindly run npm ci/build in that folder and describe it as a port. Implement in the destination repository and validate there. The included tests exercise original source paths; adapt their intent to the destination rather than disabling assertions to make them pass.

No deployment is requested as part of this handoff. Use the new project's own environment and deployment contract. Do not copy the SSD VPS path, ports, Nginx routes, PM2 names or production credentials from source comments into a new application's operational configuration.
