# Database model reference

Exact selected model definitions from the inspected source. References to contextual models are intentional and require migration/adaptation. The complete schema remains in reference-source/prisma/schema.prisma.

## Selected module models

### User

```prisma
model User {
  id            String   @id @default(uuid()) @db.Uuid
  email         String   @unique
  password_hash String
  is_admin      Boolean  @default(false)
  role          String   @default("sub_user")
  full_name     String   @default("")
  is_active     Boolean  @default(true)
  modules       String[] @default(["accounts", "quick-invoice"])
  created_at    DateTime @default(now()) @db.Timestamptz(6)

  @@map("users")
}
```

### Product

```prisma
model Product {
  id           String   @id @default(uuid()) @db.Uuid
  code         String   @unique
  name         String
  description  String?  @default("")
  cost_price   Decimal  @default(0) @db.Decimal(20, 8)
  packaging_enabled Boolean @default(false)
  base_unit String @default("Piece")
  pieces_per_packet Int @default(1)
  packets_per_box Int @default(1)
  packet_sale_price Decimal @default(0) @db.Decimal(12, 2)
  box_sale_price Decimal @default(0) @db.Decimal(12, 2)
  packaging_converted_at DateTime? @db.Timestamptz(6)
  sale_price   Decimal  @default(0) @db.Decimal(12, 2)
  pricing_type String   @default("standalone")
  category_id  String?  @db.Uuid
  category     ProductCategory? @relation(fields: [category_id], references: [id], onDelete: SetNull)
  quantity     Decimal      @default(0) @db.Decimal(14, 2)
  expiry_date  DateTime? @db.Date
  invoice_items InvoiceItem[]
  stock_batches StockBatch[]
  return_items InvoiceReturnItem[]
  created_at   DateTime @default(now()) @db.Timestamptz(6)

  @@map("products")
  @@index([category_id])
}
```

### ProductCategory

```prisma
model ProductCategory {
  id         String   @id @default(uuid()) @db.Uuid
  name       String
  name_key   String   @unique
  created_at DateTime @default(now()) @db.Timestamptz(6)
  products   Product[]

  @@map("product_categories")
}
```

### Cashbook

```prisma
model Cashbook {
  supplier_return SupplierReturn?
  invoice_return InvoiceReturn?
  id               String   @id @default(uuid()) @db.Uuid
  type             String
  description      String
  amount           Decimal  @db.Decimal(12, 2)
  date             DateTime @db.Date
  method           String   @default("Cash")
  reference        String   @default("")
  account_name     String   @default("")
  created_by_email String   @default("")
  created_by_name  String   @default("")
  created_at       DateTime @default(now()) @db.Timestamptz(6)

  purchase_orders PurchaseOrder[]
  expenses        Expense[]

  @@map("cashbook")
}
```

### Expense

```prisma
model Expense {
  id                String    @id @default(uuid()) @db.Uuid
  expense_number    String?   @unique
  category          String    @default("")
  invoice_id        String?   @db.Uuid
  invoice_number    String    @default("")
  description       String    @default("")
  amount            Decimal   @default(0) @db.Decimal(12, 2)
  date              DateTime  @db.Date
  method            String    @default("Cash")
  completed         Boolean   @default(false)
  cashbook_entry_id String?   @db.Uuid
  created_by_email  String    @default("")
  created_by_name   String    @default("")
  created_at        DateTime  @default(now()) @db.Timestamptz(6)
  invoice           Invoice?  @relation(fields: [invoice_id], references: [id], onDelete: SetNull)
  cashbook_entry    Cashbook? @relation(fields: [cashbook_entry_id], references: [id], onDelete: SetNull)

  @@map("expenses")
}
```

### Supplier

```prisma
model Supplier {
  id              String          @id @default(uuid()) @db.Uuid
  name            String
  phone           String          @default("")
  address         String          @default("")
  notes           String          @default("")
  opening_balance Decimal         @default(0) @db.Decimal(12, 2)
  created_at      DateTime        @default(now()) @db.Timestamptz(6)
  purchase_orders PurchaseOrder[]

  @@map("suppliers")
}
```

### PurchaseOrder

```prisma
model PurchaseOrder {
  returns SupplierReturn[]
  id                String              @id @default(uuid()) @db.Uuid
  po_number         String              @unique
  supplier_id       String?             @db.Uuid
  supplier_name     String
  supplier_phone    String              @default("")
  order_date        DateTime            @db.Date
  notes             String              @default("")
  subtotal          Decimal             @default(0) @db.Decimal(12, 2)
  grand_total       Decimal             @default(0) @db.Decimal(12, 2)
  amount_paid       Decimal             @default(0) @db.Decimal(12, 2)
  balance_due       Decimal             @default(0) @db.Decimal(12, 2)
  payment_status    String              @default("unpaid")
  payment_method    String              @default("Cash")
  cashbook_entry_id String?             @db.Uuid
  created_by_email  String              @default("")
  created_by_name   String              @default("")
  created_at        DateTime            @default(now()) @db.Timestamptz(6)
  supplier          Supplier?           @relation(fields: [supplier_id], references: [id], onDelete: SetNull)
  cashbook_entry    Cashbook?           @relation(fields: [cashbook_entry_id], references: [id], onDelete: SetNull)
  items             PurchaseOrderItem[]

  @@map("purchase_orders")
}
```

### PurchaseOrderItem

```prisma
model PurchaseOrderItem {
  return_items SupplierReturnItem[]
  id                String        @id @default(uuid()) @db.Uuid
  purchase_order_id String        @db.Uuid
  description       String        @default("")
  product_id        String?       @db.Uuid
  expiry_date       DateTime?     @db.Date
  unit_factor Decimal @default(1) @db.Decimal(14, 2)
  stock_received_qty Decimal          @default(0) @db.Decimal(14, 2)
  stock_batch       StockBatch?
  unit              String        @default("pcs")
  qty               Decimal       @default(1) @db.Decimal(12, 2)
  rate              Decimal       @default(0) @db.Decimal(12, 2)
  amount            Decimal       @default(0) @db.Decimal(12, 2)
  purchase_order    PurchaseOrder @relation(fields: [purchase_order_id], references: [id], onDelete: Cascade)

  @@map("purchase_order_items")
}
```

### StockBatch

```prisma
model StockBatch {
  supplier_returns SupplierReturnItem[]
  id                    String            @id @default(uuid()) @db.Uuid
  product_id            String            @db.Uuid
  product               Product           @relation(fields: [product_id], references: [id], onDelete: Restrict)
  purchase_item_id       String?           @unique @db.Uuid
  purchase_item         PurchaseOrderItem? @relation(fields: [purchase_item_id], references: [id], onDelete: Restrict)
  received_qty          Decimal @db.Decimal(14, 2)
  remaining_qty         Decimal @db.Decimal(14, 2)
  unit_cost Decimal? @db.Decimal(20, 8)
  expiry_date           DateTime?          @db.Date
  received_date         DateTime           @db.Date
  created_at            DateTime           @default(now()) @db.Timestamptz(6)
  allocations           StockAllocation[]

  @@map("stock_batches")
  @@index([product_id, received_date, created_at])
}
```

### StockAllocation

```prisma
model StockAllocation {
  returns               ReturnStockAllocation[]
  id                    String      @id @default(uuid()) @db.Uuid
  invoice_id            String      @db.Uuid
  invoice               Invoice     @relation(fields: [invoice_id], references: [id], onDelete: Cascade)
  batch_id              String      @db.Uuid
  batch                 StockBatch  @relation(fields: [batch_id], references: [id], onDelete: Restrict)
  qty                   Decimal @db.Decimal(14, 2)
  created_at            DateTime    @default(now()) @db.Timestamptz(6)

  @@map("stock_allocations")
  @@unique([invoice_id, batch_id])
}
```

### Worker

```prisma
model Worker {
  id                    String          @id @default(uuid()) @db.Uuid
  name                  String
  phone                 String          @default("")
  role                  String          @default("")
  monthly_wage          Decimal         @default(0) @db.Decimal(12, 2)
  status                String          @default("Active")
  hourly_overtime_rate  Decimal         @default(0) @db.Decimal(12, 2)
  standard_working_days Int             @default(26)
  created_at            DateTime        @default(now()) @db.Timestamptz(6)
  advances              WorkerAdvance[]
  payments              WorkerPayment[]
  extra_hours           WorkerExtraHours[]

  @@map("workers")
}
```

### WorkerExtraHours

```prisma
model WorkerExtraHours {
  id            String   @id @default(uuid()) @db.Uuid
  worker_id     String?  @db.Uuid
  month         String
  hours         Decimal  @db.Decimal(10, 2)
  rate_per_hour Decimal  @db.Decimal(12, 2)
  amount        Decimal  @db.Decimal(12, 2)
  payment_id    String?  @db.Uuid
  created_at    DateTime @default(now()) @db.Timestamptz(6)
  worker        Worker?  @relation(fields: [worker_id], references: [id], onDelete: Cascade)

  @@map("worker_extra_hours")
}
```

### WorkerAdvance

```prisma
model WorkerAdvance {
  id                String   @id @default(uuid()) @db.Uuid
  worker_id         String?  @db.Uuid
  amount            Decimal  @db.Decimal(12, 2)
  date              DateTime @db.Date
  month             String
  notes             String   @default("")
  cashbook_entry_id String?  @db.Uuid
  created_at        DateTime @default(now()) @db.Timestamptz(6)
  worker            Worker?  @relation(fields: [worker_id], references: [id], onDelete: Cascade)

  @@map("worker_advances")
}
```

### WorkerPayment

```prisma
model WorkerPayment {
  id                 String   @id @default(uuid()) @db.Uuid
  worker_id          String?  @db.Uuid
  month              String
  total_wage         Decimal  @default(0) @db.Decimal(12, 2)
  advance_total      Decimal  @default(0) @db.Decimal(12, 2)
  net_paid           Decimal  @default(0) @db.Decimal(12, 2)
  paid_date          DateTime @db.Date
  cashbook_entry_id  String?  @db.Uuid
  notes              String   @default("")
  overtime_hours     Decimal  @default(0) @db.Decimal(10, 2)
  overtime_amount    Decimal  @default(0) @db.Decimal(12, 2)
  absent_days        Decimal  @default(0) @db.Decimal(8, 2)
  absence_deduction  Decimal  @default(0) @db.Decimal(12, 2)
  created_by_email   String   @default("")
  created_by_name    String   @default("")
  created_at         DateTime @default(now()) @db.Timestamptz(6)
  worker             Worker?  @relation(fields: [worker_id], references: [id], onDelete: Cascade)

  @@map("worker_payments")
}
```

### PaymentMethod

```prisma
model PaymentMethod {
  id              String   @id @default(uuid()) @db.Uuid
  name            String   @unique
  opening_balance Decimal  @default(0) @db.Decimal(12, 2)
  archived        Boolean  @default(false)
  sort_order      Int      @default(0)
  created_at      DateTime @default(now()) @db.Timestamptz(6)

  @@map("payment_methods")
}
```

### ActivityLog

```prisma
model ActivityLog {
  id          String   @id @default(uuid()) @db.Uuid
  action      String
  entity_type String
  entity_id   String   @default("")
  title       String   @default("")
  subtitle    String   @default("")
  amount      Decimal? @db.Decimal(12, 2)
  metadata    String   @default("")
  user_id     String?  @db.Uuid
  user_email  String   @default("")
  user_name   String   @default("")
  created_at  DateTime @default(now()) @db.Timestamptz(6)

  @@index([created_at])
  @@index([entity_type])
  @@index([action])
  @@index([user_id])
  @@map("activity_log")
}
```

## Contextual integration models (not additional requested modules)

### HeadAccount

```prisma
model HeadAccount {
  id         String    @id @default(uuid()) @db.Uuid
  code       String    @unique
  name       String
  type       String
  bal        String
  created_at DateTime  @default(now()) @db.Timestamptz(6)
  accounts   Account[]

  @@map("head_accounts")
}
```

### Account

```prisma
model Account {
  id           String      @id @default(uuid()) @db.Uuid
  name         String
  head_id      String?     @db.Uuid
  type         String
  phone        String      @default("")
  whatsapp     String      @default("")
  address      String      @default("")
  balance      Decimal     @default(0) @db.Decimal(12, 2)
  bal_type     String      @default("debit")
  ntn          String      @default("")
  status       String      @default("Active")
  created_at   DateTime    @default(now()) @db.Timestamptz(6)
  head_account HeadAccount? @relation(fields: [head_id], references: [id])

  @@map("accounts")
}
```

### Invoice

```prisma
model Invoice {
  id               String        @id @default(uuid()) @db.Uuid
  invoice_number   String        @unique
  client_name      String
  client_phone     String        @default("")
  client_address   String        @default("")
  client_ntn       String        @default("")
  client_email     String        @default("")
  invoice_date     DateTime      @db.Date
  due_date         DateTime?     @db.Date
  payment_terms    String        @default("Net 15 Days")
  reference        String        @default("")
  subtotal         Decimal       @default(0) @db.Decimal(12, 2)
  discount_type    String        @default("pct")
  discount_value   Decimal       @default(0) @db.Decimal(12, 2)
  discount_amount  Decimal       @default(0) @db.Decimal(12, 2)
  gst_pct          Decimal       @default(0) @db.Decimal(5, 2)
  gst_amount       Decimal       @default(0) @db.Decimal(12, 2)
  stax_pct         Decimal       @default(0) @db.Decimal(5, 2)
  stax_amount      Decimal       @default(0) @db.Decimal(12, 2)
  bra_pct          Decimal       @default(0) @db.Decimal(6, 2)
  bra_amount       Decimal       @default(0) @db.Decimal(12, 2)
  previous_balance Decimal       @default(0) @db.Decimal(12, 2)
  grand_total      Decimal       @default(0) @db.Decimal(12, 2)
  amount_received  Decimal       @default(0) @db.Decimal(12, 2)
  balance_due      Decimal       @default(0) @db.Decimal(12, 2)
  payment_status   String        @default("unpaid")
  payment_method   String        @default("Cash")
  job_name         String        @default("")
  job_location     String        @default("")
  job_start        DateTime?     @db.Date
  job_end          DateTime?     @db.Date
  job_notes        String        @default("")
  is_walk_in       Boolean       @default(false)
  created_by_email String        @default("")
  created_by_name  String        @default("")
  created_at       DateTime      @default(now()) @db.Timestamptz(6)
  items            InvoiceItem[]
  stock_allocations StockAllocation[]
  returns          InvoiceReturn[]
  quotations       Quotation[]
  expenses         Expense[]

  @@map("invoices")
}
```

### InvoiceItem

```prisma
model InvoiceItem {
  return_items InvoiceReturnItem[]
  discount_pct Decimal @default(0) @db.Decimal(5, 2)
  id          String   @id @default(uuid()) @db.Uuid
  invoice_id  String?  @db.Uuid
  category    String   @default("Billboard")
  description String   @default("")
  width       Decimal  @default(0) @db.Decimal(8, 2)
  height      Decimal  @default(0) @db.Decimal(8, 2)
  sqft        Decimal  @default(0) @db.Decimal(10, 2)
  rate        Decimal  @default(0) @db.Decimal(10, 2)
  qty         Decimal      @default(1) @db.Decimal(14, 2)
  product_id  String?  @db.Uuid
  product     Product? @relation(fields: [product_id], references: [id], onDelete: Restrict)
  unit String @default("unit")
  unit_factor Decimal @default(1) @db.Decimal(14, 2)
  stock_deducted_qty Decimal @default(0) @db.Decimal(14, 2)
  amount      Decimal  @default(0) @db.Decimal(12, 2)
  invoice     Invoice? @relation(fields: [invoice_id], references: [id], onDelete: Cascade)

  @@map("invoice_items")
  @@index([product_id])
}
```

### SupplierReturn

```prisma
model SupplierReturn {
  id String @id @default(uuid()) @db.Uuid
  request_id String @unique @db.Uuid
  purchase_order_id String @db.Uuid
  purchase_order PurchaseOrder @relation(fields: [purchase_order_id], references: [id], onDelete: Restrict)
  return_date DateTime @db.Date
  reason String @default("")
  amount Decimal @db.Decimal(12, 2)
  credit_entry_id String? @unique @db.Uuid
  credit_entry Cashbook? @relation(fields: [credit_entry_id], references: [id], onDelete: Restrict)
  created_by_email String @default("")
  created_by_name String @default("")
  created_at DateTime @default(now()) @db.Timestamptz(6)
  items SupplierReturnItem[]

  @@map("supplier_returns")
  @@index([purchase_order_id, return_date])
}
```

### SupplierReturnItem

```prisma
model SupplierReturnItem {
  id String @id @default(uuid()) @db.Uuid
  return_id String @db.Uuid
  supplier_return SupplierReturn @relation(fields: [return_id], references: [id], onDelete: Restrict)
  purchase_item_id String @db.Uuid
  purchase_item PurchaseOrderItem @relation(fields: [purchase_item_id], references: [id], onDelete: Restrict)
  batch_id String? @db.Uuid
  batch StockBatch? @relation(fields: [batch_id], references: [id], onDelete: Restrict)
  product_name String
  description String @default("")
  qty Decimal @db.Decimal(14, 2)
  unit String @default("unit")
  stock_removed_qty Decimal @default(0) @db.Decimal(14, 2)
  amount Decimal @db.Decimal(12, 2)

  @@map("supplier_return_items")
  @@unique([return_id, purchase_item_id])
  @@index([purchase_item_id])
  @@index([batch_id])
}
```

### InvoiceReturn

```prisma
model InvoiceReturn {
  id                String @id @default(uuid()) @db.Uuid
  request_id        String @unique @db.Uuid
  invoice_id        String @db.Uuid
  invoice           Invoice @relation(fields: [invoice_id], references: [id], onDelete: Restrict)
  return_date       DateTime @db.Date
  reason            String @default("")
  amount            Decimal @db.Decimal(12, 2)
  credit_entry_id   String? @unique @db.Uuid
  credit_entry      Cashbook? @relation(fields: [credit_entry_id], references: [id], onDelete: Restrict)
  created_by_email  String @default("")
  created_by_name   String @default("")
  created_at        DateTime @default(now()) @db.Timestamptz(6)
  items             InvoiceReturnItem[]

  @@map("invoice_returns")
  @@index([invoice_id, return_date])
}
```

### InvoiceReturnItem

```prisma
model InvoiceReturnItem {
  id                 String @id @default(uuid()) @db.Uuid
  return_id          String @db.Uuid
  invoice_return     InvoiceReturn @relation(fields: [return_id], references: [id], onDelete: Restrict)
  invoice_item_id    String @db.Uuid
  invoice_item       InvoiceItem @relation(fields: [invoice_item_id], references: [id], onDelete: Restrict)
  product_id         String? @db.Uuid
  product            Product? @relation(fields: [product_id], references: [id], onDelete: Restrict)
  product_name       String
  description        String @default("")
  qty                Decimal @db.Decimal(14, 2)
  unit String @default("unit")
  stock_restored_qty Decimal @default(0) @db.Decimal(14, 2)
  amount             Decimal @db.Decimal(12, 2)
  revenue            Decimal @db.Decimal(12, 2)
  allocations        ReturnStockAllocation[]

  @@map("invoice_return_items")
  @@unique([return_id, invoice_item_id])
  @@index([invoice_item_id])
  @@index([product_id])
}
```

### ReturnStockAllocation

```prisma
model ReturnStockAllocation {
  id                 String @id @default(uuid()) @db.Uuid
  return_item_id     String @db.Uuid
  return_item        InvoiceReturnItem @relation(fields: [return_item_id], references: [id], onDelete: Restrict)
  stock_allocation_id String @db.Uuid
  stock_allocation   StockAllocation @relation(fields: [stock_allocation_id], references: [id], onDelete: Restrict)
  qty                Decimal @db.Decimal(14, 2)

  @@map("return_stock_allocations")
  @@unique([return_item_id, stock_allocation_id])
}
```
