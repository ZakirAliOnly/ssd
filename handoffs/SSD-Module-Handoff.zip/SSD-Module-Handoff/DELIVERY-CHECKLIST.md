# Developer delivery checklist

- All ten requested modules implemented in the destination app, with working persistence and server permissions.
- Destination module registry and allowed defaults defined; original out-of-scope routes not accidentally granted.
- Workers, expenses, transfers and supplier payment commands create coherent linked cash records atomically.
- Source financial formulas and decimal/date representations preserved; intentional differences documented.
- Product batch, quantity, packaging-factor and cost history reconciles.
- Current-user/role checks happen server-side; audit actor is not client-controlled; passwords never returned.
- Login, shell and implemented print/PDF credit display correctly with destination branding.
- Synthetic fixtures and acceptance checks supplied with pass/fail/unrun outcomes.
- Build and type checks pass; browser workflows exercised; failures investigated rather than hidden.
- Database migrations, setup commands and variable names documented without secret values.
- Known limitations, optional adapters and changed legacy behaviors documented in a decision log.
- No production SSD connection, records, credentials or external messages used in implementation/testing.
